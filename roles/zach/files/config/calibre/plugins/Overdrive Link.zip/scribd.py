﻿#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

from __future__ import (unicode_literals, division, absolute_import, print_function)

import re
import time
import json

from calibre.utils.date import parse_only_date

from calibre_plugins.overdrive_link.numbers import value_unit
from calibre_plugins.overdrive_link.book import (LibraryBook, InfoBook)
from calibre_plugins.overdrive_link.formats import (FORMAT_SCRIBD_BOOK_READER, FORMAT_SCRIBD_COMIC_READER, FORMAT_SCRIBD_AUDIOBOOK)
from calibre_plugins.overdrive_link.json import js_value
from calibre_plugins.overdrive_link.library import SearchableLibrary
from calibre_plugins.overdrive_link.net import (open_url, SCRIBD_MOBILE_UAGENT)
from calibre_plugins.overdrive_link.match import is_any_same_author
from calibre_plugins.overdrive_link.author_prep import normalize_author
from calibre_plugins.overdrive_link.title_prep import normalize_title
from calibre_plugins.overdrive_link.parseweb import (LibraryError, class_contains, must_find, text_only, beautiful_soup)

from .python_transition import (IS_PYTHON2)
if IS_PYTHON2:
    from .python_transition import (http, repr, str, urllib)
else:
    import http.cookiejar
    import urllib.parse


__license__ = 'GPL v3'
__copyright__ = '2021, John Howell <jhowell@acm.org>'


ENABLE_SIGN_IN = False      # not working as of November 2021, 500-error, possibly needs recaptcha result
SEARCH_BY_AUTHOR = True     # perform search by author to avoid large numbers of incorrect results, but sometimes misses books
SEARCH_FOR_COMICS = True    # searching for comics is slow, messy, and hard to maintain in the future

# Scribd returns a 'forbidden' error when requests are received too quickly. Take a long delay when this is detected.
# Pace requests to try to avoid this condition.

OVERALL_MAX_QPS = 2.0       # maximum queries per second for Scribd across all jobs
THROTTLE_DELAY = 300.0      # seconds to delay when throttled by Scribd
OOPS_DELAY = 30.0           # seconds to delay when Scribd has an internal error

LANGUAGES = {
    'English': 1,
    'Chinese': 6,
    'Spanish': 4,
    'Arabic': 11,
    'Portuguese': 13,
    'Japanese': 3,
    'German': 9,
    'French': 5,
    'Korean': 7,
    'Turkish': 78,
    'Vietnamese': 103,
    'Russian': 14,
    'Tamil': 104,
    'Italian': 8,
    'Thai': 60,
    'Polish': 89,
    }

NON_ENGLISH_WORDS = {
    # German
    "aber", "als", "andere", "anderer", "anderes", "auch", "auf", "aus", "bei", "beispiel",
    "bin", "bis", "da", "damit", "dann", "das", "dass", "dem", "den", "denn", "der", "dich", "dir", "doch",
    "du", "durch", "eigentlich", "ein", "eine", "einen", "er", "erste", "erster", "erstes", "es", "für", "ganz",
    "geben", "gehen", "groß", "habe", "haben", "hier", "ich", "ihm", "ihn", "ihr", "immer", "ist", "ja", "jahr",
    "jede", "jeder", "jedes", "jetzt", "können", "kann", "kein", "kommen", "lassen", "müssen", "machen", "mehr",
    "mein", "mich", "mir", "mit", "nach", "nein", "neu", "nicht", "noch", "nur", "oben", "oder", "sagen", "schon",
    "sehen", "sehr", "sein", "selber", "selbst", "sich", "sie", "sind", "sollen", "stehen", "über", "um", "und",
    "uns", "unser", "unter", "viel", "von", "vor", "weil", "wenn", "werden", "wie", "wieder", "wir", "wissen",
    "wo", "wollen", "zeit", "zu", "zwei",

    "la", "de", "și", "ce", "ca", "un", "cu", "nu", "va", "să", "că", "fi", "mai",
    }

NON_ENGLISH_LETTERS = r"[àáâãäăåāăąèéêëēĕėęěìíîïĩīĭįıòóôõöōŏőơùúûüũūŭůűųñńņňýÿƴßșțçćĉċč]"    # as a re pattern


FORMAT_OF_CONTENT_TYPE = {
    'books': FORMAT_SCRIBD_BOOK_READER,
    'audiobooks': FORMAT_SCRIBD_AUDIOBOOK,
    'comics': FORMAT_SCRIBD_COMIC_READER,
    }

CONTENT_KEYS = {
    'books': 'authored_documents',
    'audiobooks': 'authored_audiobooks',
    'comics': 'authored_comics',
    }

SEARCH_APP = "React.createElement(Scribd.Search.App,"


class Scribd(SearchableLibrary):
    id = 'sc'
    name = 'Scribd'
    formats_supported = {FORMAT_SCRIBD_BOOK_READER, FORMAT_SCRIBD_COMIC_READER, FORMAT_SCRIBD_AUDIOBOOK}

    @staticmethod
    def validate_library_id(library_id, migrate=True, config=None):
        if library_id:
            raise ValueError('Scribd library id must be left blank: "%s"' % library_id)

        return library_id

    @staticmethod
    def validate_book_id(book_id, library_id):
        if not re.match(r'^([0-9]+)$', book_id):
            raise ValueError('Scribd book id must be numeric: "%s"' % book_id)

        return book_id

    @staticmethod
    def book_url(library_id, book_id):
        # Using /book/ will redirect properly for audiobooks
        return 'https://www.scribd.com/book/%s' % book_id

    def __init__(self):
        self.cookiejar = http.cookiejar.CookieJar()
        self.authors_searched = set()
        self.ids_of_author = {}
        self.author_content_types = {}
        self.filter_reported = False

    def sign_in(self, use_credentials):
        if self.card_number and use_credentials and ENABLE_SIGN_IN:
            # sign in to Scribd to produce selective results
            self.cookiejar.clear()
            self.signin_required = True

            self.log.info('Signing in to %s' % self.name)

            response = open_url(self.log, 'https://www.scribd.com/login', cookiejar=self.cookiejar)     # establish session
            soup = beautiful_soup(response.data_string)

            csrf_token = must_find(soup, 'meta', attrs={'name': 'csrf-token'}).get('content')

            data = {}
            data['login_or_email'] = self.card_number
            data['login_password'] = self.card_pin
            data['rememberme'] = ''
            #data['g-recaptcha-response'] = ?
            data['signup_location'] = 'https://www.scribd.com/login'
            data['login_params'] = {}

            response = open_url(
                        self.log, 'https://www.scribd.com/login', urllib.parse.urlencode(data),
                        addheaders=[
                            ('Accept', '*/*'),
                            ("x-csrf-token", csrf_token),
                            ("x-requested-with", "XMLHttpRequest")],
                        cookiejar=self.cookiejar, referer='https://www.scribd.com/login',
                        origin='https://www.scribd.com')

            #self.log.info("login response: %s" % response.data_string)

            if response.response_type != 'application/json':
                raise LibraryError('Sign in failed. Unexpected response type %s' % response.response_type)

            results = json.loads(response.data_string)      # Parse the json results

            if "errors" in results:
                raise LibraryError('Sign in failed. %s' % results["errors"][0]["msg"])

            login = results.get("login", None)
            success = results.get("success", None)

            if not (login and success):
                raise LibraryError('Sign in failed. login=%s, success=%s' % (str(login), str(success)))

            self.log.info('Sign in to Scribd successful')
            self.signed_in = True

    def open_scribd_url(self, url, **kwargs):
        book_id = kwargs.pop('book_id', None)
        kwargs['expect_errors'] = [403, 410, 500]
        kwargs['qps'] = OVERALL_MAX_QPS

        tries = 0
        MAX_TRIES = 3

        while True:
            tries += 1
            response = open_url(self.log, url, **kwargs)

            if response.is_httperror_exception:
                if response.code == 403:
                    # error 403 (forbidden) occurs for throttling if requests are received too quickly by scribd.

                    #self.log.info('headers: %s' % response.headers)
                    #self.log.info('Forbidden: ' + response.response_data)

                    if 'your computer or network may be sending automated search queries' in response.response_data:
                        self.log.info('Delaying due to throttling')
                        time.sleep(THROTTLE_DELAY)
                        continue

                if book_id:
                    if response.code == 410:
                        # error 410 (gone) occurs if book is not authorized or has been removed from scribd.
                        #self.log.info('headers: %s' % response.headers)

                        if 'This document is not publicly available.' in response.response_data:
                            self.log.info('Access denied: %s is not publically available' % book_id)
                        elif 'Deletion notice' in response.response_data:
                            self.log.info('Deleted: %s is no longer available' % book_id)
                        else:
                            self.log.info('Gone: %s is not available' % book_id)

                        return None

                    if response.code == 500:
                        # occurs consistently for some books that are not accessible
                        self.log.warn('Internal Server Error: %s is not available' % book_id)
                        return None

                raise response

            if "<h1>Oops! Something went wrong.</h1>" in response.data_string:
                if tries > MAX_TRIES:
                    self.log.warn('Server Error: Oops! Something went wrong.')
                    return None

                self.log.info('Server Error: Oops! Something went wrong.')
                time.sleep(OOPS_DELAY)
                continue

            redirect_url = response.geturl()
            redirect_path = urllib.parse.urlparse(redirect_url).path

            if len(redirect_path) < 2:
                raise LibraryError('Scribd redirected query to home page - Retry search later')

            break

        return response

    def report_filter(self):
        if (not self.filter_reported) and (not self.signed_in):
            self.log.error('Scribd results are being filtered. Providing credentials to sign in to Scribd may prevent this problem.')
            self.filter_reported = True

    def find_books(self, books, search_author, search_title, keyword_search):
        # doing search of Scribd by query performs poorly since it returns excessive non-matching results

        for content_type in ['books', 'audiobooks', 'comics']:
            if content_type == 'comics' and not SEARCH_FOR_COMICS:
                continue

            search_format = FORMAT_OF_CONTENT_TYPE[content_type]

            if search_format not in self.config.search_formats:
                continue    # skip undesired formats

            if SEARCH_BY_AUTHOR and not keyword_search:
                if self.find_books_using_author(books, search_author, content_type):
                    return True     # Too many results
            else:
                RESULTS_PER_PAGE = 40
                MAX_PAGES_FOR_NON_AUTHOR_SEARCH = 3
                MAX_RESULTS_ALLOWED = 500 if keyword_search else 200

                page_num = 1
                total_pages = 1
                total_results = 0
                results_processed = 0

                while (page_num <= total_pages):
                    data = {}
                    query = []

                    if search_author:
                        query.append(search_author.replace("'", "").replace('.', ''))   # extraneous chars cause huge number of results

                    if search_title:
                        query.append(search_title)

                    data['query'] = ' '.join(query)

                    if self.config.search_language and self.config.search_language in LANGUAGES:
                        language = self.config.search_language
                        data['language'] = '%d' % LANGUAGES[self.config.search_language]
                    else:
                        language = ''

                    data['page'] = '%d' % page_num

                    # tops (all), books, audiobooks, comics, authors, documents, sheet_music, collections, users
                    data['content_type'] = content_type

                    response = self.open_scribd_url('https://www.scribd.com/search?%s' % urllib.parse.urlencode(data),
                                                    cookiejar=self.cookiejar)

                    # Parse the html results for analysis
                    soup = beautiful_soup(response.data_string)

                    scripts = soup.findAll('script', attrs={'type': "text/javascript"})
                    for script in scripts:
                        if SEARCH_APP in str(script):
                            search_info = js_value(self.log, str(script), SEARCH_APP)
                            break
                    else:
                        raise Exception('Missing %s' % SEARCH_APP)

                    #self.log.info('Search.App: %s' % str(search_info))

                    result_count = search_info['result_count']

                    if isinstance(result_count, str):
                        result_count = int(result_count)

                    if (result_count is None) or (result_count == 0):
                        break

                    if total_results and (result_count != total_results):
                        self.log.info('Total results changed from %d to %d' % (total_results, result_count))

                    total_results = result_count
                    total_pages = ((total_results - 1) // RESULTS_PER_PAGE) + 1  # floor division

                    self.log.info('Response: page %d of %d. %d total results' % (page_num, total_pages, total_results))

                    if (total_pages > MAX_PAGES_FOR_NON_AUTHOR_SEARCH) and not keyword_search:
                        # too many results - author name is a common term. Do search specifically by author.
                        self.log.info('Too many results -- switching to search by author')
                        if self.find_books_using_author(books, search_author, content_type):
                            return True

                        results_processed = total_results   # prevent warning
                        break

                    documents = search_info['results'][content_type]['content']['documents']

                    for doc in documents:
                        book_id = str(doc['id'])
                        title = doc['title']
                        authors = [doc['author']]
                        available = not doc['availability']['text']

                        lbook = LibraryBook(authors=authors, title=title, language=language,
                                            available=available, recommendable=not available, lib=self, book_id=book_id,
                                            search_author=search_author)

                        if not available:
                            self.log.info('Ignoring unavailable: %s' % repr(lbook))
                        else:
                            self.log.info('Found: %s' % repr(lbook))
                            books.add(lbook)

                        results_processed += 1

                    if results_processed >= MAX_RESULTS_ALLOWED:
                        return True

                    page_num += 1

                if results_processed != total_results:
                    # this happens frequently for Scribd
                    self.log.info('Expected %s results but found %d' % (value_unit(total_results, 'book'), results_processed))
                    self.report_filter()

        return False

    def process_search_result(self, books, search_author, doc, content_type, language):
        authors = []
        title = ''
        available = True

        book_id = doc['data-object_id']
        book_classes = doc['class']
        if not isinstance(book_classes, list):
            book_classes = book_classes.split()

        document_title = doc.find('div', attrs={'class': 'document_title'})
        if document_title:
            title_text = text_only(document_title)
            if not title_text.endswith('...'):
                title = normalize_title(title_text)

        document_author = doc.find('div', attrs={'class': 'document_author'})
        if document_author:
            # May contain non-author contributors. These will be eliminated by get_book_info
            for a in document_author.findAll('a', recursive=True):
                authors.append(normalize_author(text_only(a), unreverse=False))

        for flag_div in doc.findAll('div', attrs={'class': 'flag'}, recursive=True):
            flag_text = text_only(flag_div).lower()
            if flag_text == "not available" or flag_text == "sample":
                available = False

            #flag='!' for audiobook requiring a credit

        audiobook_indicator = doc.find('div', attrs={'class': 'audiobook_indicator'}) is not None
        audiobook_indicator = audiobook_indicator or ('is_audiobook' in book_classes)

        if audiobook_indicator != (content_type == 'audiobooks'):
            raise LibraryError('Format mismatch: content_type=%s, audiobook_indicator=%s' % (
                    content_type, str(audiobook_indicator)))

        # don't specify format since may have been removed even if shown in search results

        lbook = LibraryBook(authors=authors, title=title, language=language,
                            available=available, recommendable=not available, lib=self, book_id=book_id,
                            search_author=search_author)

        if not available:
            self.log.info('Ignoring unavailable: %s' % repr(lbook))
        elif 'is_comic_series' in book_classes or 'is_series' in book_classes:
            if content_type == 'comics':
                self.log.info('Getting contents of comic series: %s' % repr(lbook))
                for book_id in self.get_series_info(book_id):

                    lbook = LibraryBook(authors=authors, title=title, language=language,
                                        available=True, recommendable=False, lib=self, book_id=book_id,
                                        search_author=search_author)
                    if not self.is_book_available(book_id):
                        self.log.info('Ignoring unavailable comic in series: %s' % repr(lbook))
                    else:
                        self.log.info('Found comic in series: %s' % repr(lbook))
                        books.add(lbook)
            else:
                self.log.info('Ignoring %s series: %s' % (content_type, repr(lbook)))
        else:
            self.log.info('Found: %s' % repr(lbook))
            books.add(lbook)

    def find_books_using_author(self, books, search_author, content_type):
        '''
        faster than a general search using a common author name, but cannot filter by language or title

        This is not used by default because it takes more queries to produce results and because some books
        are not findable in the author's book list even though they link back to the proper author.
        Some examples are:
            https://www.scribd.com/book/206531958/Nightside-CIty
            https://www.scribd.com/book/205643330/The-Vondish-Ambassador-A-Legend-of-Ethshar
        '''

        author_ids = self.find_author_ids(search_author)

        for author_id in author_ids:
            if (author_id, content_type) in self.authors_searched:
                self.log.info('Already searched Scribd author user id %s for %s' % (author_id, content_type))

            elif content_type not in self.author_content_types[author_id]:
                pass    # this author has no content of this type

            else:
                self.authors_searched.add((author_id, content_type))

                RESULTS_PER_PAGE = 49   # 7x7 grid
                MAX_RESULTS_ALLOWED = 500

                page_num = 1
                results_processed = 0
                content_url = self.author_content_types[author_id][content_type]

                while True:
                    response = self.open_scribd_url(
                            '%s?page=%d' % (content_url, page_num), cookiejar=self.cookiejar,
                            referer=content_url, addheaders=[
                                ('Accept', 'application/json, text/javascript, */*; q=0.01'),
                                ("X-Tried-CSRF", "1"), ("X-Requested-With", "XMLHttpRequest")])

                    data = json.loads(response.data_string)

                    count = data['count']
                    if not count:
                        break

                    documents = data['content']

                    # Parse the html results for analysis
                    soup = beautiful_soup(documents)

                    # class="document_grid document_drop object_grid has_document_cells"
                    authored_docs = must_find(soup, 'div', attrs=class_contains('document_grid'))

                    # class="object_cell document_cell   has_flag is_geo_restricted  is_book"
                    docs = authored_docs.findAll('li', attrs=class_contains('document_cell'), recursive=True)

                    if not docs:
                        docs = authored_docs.findAll('div', attrs=class_contains('document_cell'), recursive=True)

                    if len(docs) != count:
                        self.log.warn('count=%d but have %d results' % (count, len(docs)))

                    if len(docs) > RESULTS_PER_PAGE:
                        self.log.warn('results_per_page=%d but have %d results' % (RESULTS_PER_PAGE, len(docs)))

                    for doc in docs:
                        self.process_search_result(books, search_author, doc, content_type, '')
                        results_processed += 1

                        if results_processed > MAX_RESULTS_ALLOWED:
                            return True     # limit_exceeded

                    if (len(docs) < RESULTS_PER_PAGE) or not data['has_more']:
                        break

                    page_num += 1

        return False

    def find_author_ids(self, search_author):
        if search_author not in self.ids_of_author:
            self.ids_of_author[search_author] = set()

            if search_author:
                page_num = 1

                data = {}
                data['query'] = search_author
                data['page'] = '%d' % page_num
                data['content_type'] = 'authors'

                response = self.open_scribd_url('https://www.scribd.com/search?%s' % (
                    urllib.parse.urlencode(data)), cookiejar=self.cookiejar)

                # Parse the html results
                soup = beautiful_soup(response.data_string)

                scripts = soup.findAll('script', attrs={'type': "text/javascript"})
                for script in scripts:
                    if SEARCH_APP in str(script):
                        search_info = js_value(self.log, str(script), SEARCH_APP)
                        break
                else:
                    raise Exception('Missing %s' % SEARCH_APP)

                #self.log.info('Search.App: %s' % str(search_info))

                total_results = int(search_info['result_count'])
                author_results = search_info['results']['authors']['content']['users'] if total_results else []

                if 'top_result' in search_info and 'authors' in search_info['top_result']:
                    total_results += 1
                    author_results.extend(search_info['top_result']['authors']['content']['users'])

                self.log.info('Response: %d of %d total results' % (len(author_results), total_results))

                for author in author_results:
                    if is_any_same_author([search_author], [author['name']], self.config):
                        user_id = str(author['id'])
                        self.ids_of_author[search_author].add(user_id)
                        if user_id not in self.author_content_types:
                            self.author_content_types[user_id] = self.find_author_content_types(author['contributor_url'], user_id)

                self.log.info('Name matches: %s' % ', '.join(list(self.ids_of_author[search_author])))

        return self.ids_of_author[search_author]

    def find_author_content_types(self, user_url, user_id):
        response = self.open_scribd_url(user_url, cookiejar=self.cookiejar)

        # Parse the html results
        soup = beautiful_soup(response.data_string)

        content_types = {}
        for a in soup.findAll('a', attrs=class_contains('text_btn_alt'), recursive=True):
            href = a.get('href', '')
            content_type = href.rpartition('/')[2].replace('-authored', '')
            #self.log.info('href=%s content_type=%s' % (href, content_type))

            if '/' + user_id + '/' in href and content_type in FORMAT_OF_CONTENT_TYPE:
                content_types[content_type] = href

        if not content_types:
            self.log.info('User has no content: %s' % user_url)

        return content_types

    def get_series_info(self, book_id):
        # Series content is only sent to mobile browsers. Changing user agent enables this.

        # There is a collection for each series that lists its books, but the link to this collection is only
        # available via the app api, not the web site.

        try:
            response = self.open_scribd_url(
                    'https://www.scribd.com/mobile/comic/%s' % book_id,     # ?directory=document
                    uagent=SCRIBD_MOBILE_UAGENT, book_id=book_id)

            if response is None:
                return []

            redirect_url = response.geturl()
            if '/mobile/comic/' not in redirect_url:
                self.log.info('Redirected to %s' % redirect_url)

            c_book_ids = []
            soup = beautiful_soup(response.data_string)
            info_block = soup.find('div', attrs={'class': re.compile('(info-block volumes-in-series)|(info-block series-issues)')})

            if info_block:
                for a in info_block.findAll('a', attrs={'class': 'doc_link book_link'}):
                    purl = urllib.parse.urlparse(a.get('href'))
                    m = re.match(r'^/book/([^/]+)/', purl.path)  # /book/257693689/
                    if m:
                        c_book_ids.append(m.group(1))
                    else:
                        self.log.error('Book id cannot be extracted from url: %s' % a.get('href'))
            else:
                self.log.info('No series info for %s' % book_id)

            return c_book_ids

        except Exception as e:
            self.log.exception('Getting series info for %s' % book_id, e)
            return []

    def get_book_info(self, book_id, cache):
        response = self.open_scribd_url(self.book_url(self.library_id, book_id),
                                        cookiejar=self.cookiejar, book_id=book_id)

        if response is None:
            return None

        formats = set()

        book_path = urllib.parse.urlparse(response.geturl()).path
        if book_path.startswith('/book/'):
            formats = {FORMAT_SCRIBD_BOOK_READER}    # comics are identified as "book" in URL
        elif book_path.startswith('/audiobook/'):
            formats = {FORMAT_SCRIBD_AUDIOBOOK}
        else:
            self.log.info('unknown document_type=%s' % book_path)
            return None

        soup = beautiful_soup(response.data_string)

        '''
        doc_container = soup.find('div', attrs={'class': 'doc_container'})
        if doc_container:
            self.log.info('Found a personal document instead of an e-book')
            return None
        '''

        title = ''
        authors = []
        publisher = ''
        pubdate = None
        isbn = ''

        content = soup.find('main', attrs={'data-e2e': 'content-preview-app'})
        if not content:
            self.log.error('Missing book information')
            return None

        '''
        # detect occasional too-short books that cannot be read
        length_d = content.find('div', attrs={'data-e2e': 'content-length'})
        if length_d:
            length_text = text_only(length_d)
            m = re.search(r'([0-9]+) pages', length_text, flags=re.IGNORECASE)
            if m:
                number_pages = int(m.group(1))
                if number_pages <= 15:
                    read_response = self.open_scribd_url(
                            self.book_url(self.library_id, book_id).replace('/book/', '/read/'),
                            cookiejar=self.cookiejar)
                    redirect_path = urllib.parse.urlparse(read_response.geturl()).path
                    if not redirect_path.startswith('/read/'):
                        self.log.info('Non-functional book: %s, %s' % (text_only(length_text), redirect_path))
                        formats = set()    # not available
        '''

        title_h = content.find('h1', attrs={'data-e2e': 'desktop-content-title'})
        if title_h:
            title = normalize_title(text_only(title_h))

        authors_d = content.find('p', attrs={'data-e2e': 'authors'})
        if authors_d:
            for author_a in authors_d.findAll('a', recursive=True):
                authors.append(normalize_author(text_only(author_a), unreverse=False))

        release_date_d = content.find('div', attrs={'data-e2e': 'content-preview-metadata-release-date'})
        if release_date_d:
            value_d = release_date_d.find('div', attrs={'data-e2e': 'value'})
            release_date_text = text_only(value_d)
            m = re.search(r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) [0-9]+, [0-9]+', release_date_text, flags=re.IGNORECASE)
            if m:
                try:
                    pubdate = parse_only_date(m.group(0), assume_utc=True)
                except Exception:
                    # ignore invalid dates such as Feb 30, 1970 on https://www.scribd.com/book/150477853/Tales-from-the-White-Hart
                    pass

        publisher_d = content.find('div', attrs={"data-e2e": "metadata-publisher"})
        if publisher_d:
            value_d = publisher_d.find('div', attrs={'data-e2e': 'value'})
            publisher = text_only(value_d)

        isbn_d = content.find('div', attrs={'data-e2e': 'metadata-isbn'})
        if isbn_d:
            value_d = isbn_d.find('div', attrs={'data-e2e': 'value'})
            isbn = text_only(value_d)

        if self.config.search_language == 'English':
            # detect books in other languages mistakenly found when doing English search
            description_d = content.find('div', attrs={'data-e2e': 'description'})
            if description_d:
                description = text_only(description_d)
                total_word_count = non_english_word_count = 0
                for word in description.split():
                    total_word_count += 1
                    if (word.lower() in NON_ENGLISH_WORDS) or re.search(NON_ENGLISH_LETTERS, word):
                        non_english_word_count += 1

                if ((total_word_count < 10 and non_english_word_count > 0) or
                        (float(non_english_word_count)/float(total_word_count) > 0.05)):
                    self.log.info('Ignoring non-English book found using English search')
                    formats = set()    # not available

        return InfoBook(authors=authors, title=title, isbn=isbn, publisher=publisher, pubdate=pubdate,
                        formats=formats, lib=self, book_id=book_id)

    def is_book_available(self, book_id):
        try:
            return (self.get_current_book_availability(book_id) is not False)

        except Exception as e:
            self.log.exception('Checking current availability for %s' % book_id, e)
            return False

    def get_current_book_availability(self, book_id):
        response = self.open_scribd_url(self.book_url(self.library_id, book_id),
                                        cookiejar=self.cookiejar, book_id=book_id)

        if response is None:
            return False

        self.log.info('Book has normal availability')
        return 0    # always available, assuming no pre-release titles

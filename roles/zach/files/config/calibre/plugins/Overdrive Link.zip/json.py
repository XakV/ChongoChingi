﻿#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

from __future__ import (unicode_literals, division, absolute_import, print_function)

import json
import re


__license__ = 'GPL v3'
__copyright__ = '2021, John Howell <jhowell@acm.org>'


def js_value(log, js, prefix):
    # find right place in script for needed value
    # treat spaces as optional white space and * as matching arbitrary text for match

    #log.info('load: %s' % js)

    search_re = re.escape(' %s ' % prefix).replace(r'\*', r'.+?').replace(r'\ ', r'\s*')

    m = re.search(search_re, js)
    if not m:
        log.info('re: ' + search_re)
        log.info('script: ' + js)
        raise ValueError('Missing "%s" in script' % prefix)

    start_pos = i = m.end()
    start_char = js[start_pos]

    if start_char == '[':       # list
        end_chars = ']'
    elif start_char == '{':     # dict
        end_chars = '}'
    elif start_char == '(':     # function args
        end_chars = ')'
    else:                       # simple value
        i -= 1
        start_char = None
        end_chars = ';,'

    # simple scan for terminator. Ignores braces in strings. and handles nesting
    level = 1
    in_string = False
    string_term = None
    esc_str = False

    while (level > 0):
        i += 1

        if i >= len(js):
            raise ValueError('Missing terminator')

        #log.info('ch="%s" end_chars="%s" level=%d in_string=%s'%(js[i], end_chars, level, in_string))

        if not in_string:
            if js[i] == '"' or js[i] == "'":
                in_string = True
                esc_str = False
                string_term = js[i]
                js = js[:i] + '"' + js[i+1:]   # fix string for json

            elif js[i] == start_char:
                level += 1

            elif js[i] in end_chars:
                level -= 1

        elif esc_str:
            esc_str = False

        elif js[i] == '\\':
            esc_str = True

        elif js[i] == string_term:
            in_string = False
            js = js[:i] + '"' + js[i+1:]   # fix string for json

    if js[i] in ';,':
        i -= 1  # don't include terminator

    if start_char == '(':
        json_text = "[" + js[start_pos+1:i] + "]"   # convert to list
    else:
        json_text = js[start_pos:i+1]

    #log.info('loading: %s' % json_text)

    try:
        json_data = json.loads(json_text)
    except Exception:
        log.info('loading: %s' % json_text)
        raise

    #log.info('loaded: %s' % str(json_data))

    return json_data

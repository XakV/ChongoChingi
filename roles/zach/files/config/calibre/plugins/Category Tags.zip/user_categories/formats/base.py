#!/usr/bin/env python
from __future__ import (unicode_literals, division, absolute_import,
                        print_function)

__license__   = 'GPL v3'
__copyright__ = '2021 additions by Ahmed Zaki <azaki00.dev@gmail.com>'
__docformat__ = 'restructuredtext en'

from calibre import prints
from calibre.constants import DEBUG

from calibre_plugins.category_tags.user_categories import get_cols

try:
    load_translations()
except NameError:
    prints("Category Tags::user_categories/formats/base.py - exception when loading translations")

class UserCategoriesFormat(object):

    name = ''
    identifier = ''
    filters = []

    def __init__(self, gui):
        self.gui = gui
        self.db = self.gui.current_db
        self.all_item_types = list(get_cols(self.db))

    def to_pivot(self, file_path, settings):
        raise NotImplementedError

    def from_user_categories(self):
        raise NotImplementedError

    def config_widget(self):
        return None

    def default_settings(self):
        return {}

    def validate(self, settings):
        return True
